# -*- coding: utf-8 -*-
#################################################################################
# Author      : Syncoria Inc (<https://www.syncoria.com/>)
# Copyright(c): 2004-Present Syncoria Inc
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
#################################################################################

{
  'name':'Wedding Sync',
  'description': 'Theme for Wedding',
  'version':'14.0.1.0.0',
  'author': "Syncoria Inc.",
  'website': "https://www.syncoria.com",
  'company': 'Syncoria Inc.',
  'maintainer': 'Syncoria Inc.',
  'depends': ['base', 'website', 'website_blog'],
  'data': [ 
		'views/layout.xml',
		'views/inherit_template.xml',
		'views/snippets_weddmainbanner.xml',
		'views/snippets_weddtestimonial.xml',
		'views/snippets_weddtextimg.xml',
		'views/snippets_weddinfo.xml',
		'views/snippets_weddforms.xml',
		'views/snippets_weddcounter.xml',
		'views/snippets_weddmeetbestfriend.xml',
		'views/snippets_weddsteps.xml',
		'views/pages.xml',
        'views/pages_alt.xml'
		],
    'category': 'Theme/Services',
    'summary': 'Wedding, Party, Events, Shows',
    'images': [
        'static/description/banner.png',
        'static/description/theme_weddingsync_screenshot.png',
    ],
    'live_test_url': "http://weddingsyncdemo14.syncoria.com/",
    'license': 'OPL-1',
    'support': "support@syncoria.com",
    'application': False,
    "installable": True,
}
